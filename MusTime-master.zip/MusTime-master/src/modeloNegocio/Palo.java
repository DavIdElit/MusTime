package modeloNegocio;

//Descripción: enumeración de los distinos palos que puede contener una carta de la baraja española
public enum Palo {
    bastos,oros,copas,espadas;
}
